#if condition
sales = int(input('enter amt '))

tax = 0
if sales>100:
     tax = sales*.12

total = sales+tax

print('total amt :',total)

# if else
sales = int(input('enter amt '))

tax = 0
if sales>100:
     tax = sales*.12
else:
     tax = sales*.05
total = sales+tax

print('total amt :',total)


#nested if else
a = int(input('enter data :'))
b = int(input('enter data :'))
c = int(input('enter data :'))

if a>b:
     if a>c:
          print('a is gt')
     else:
          print('c is gt')
else:
     if b>c:
          print(' b is gt')
     else:
          print('c is gt')

          







