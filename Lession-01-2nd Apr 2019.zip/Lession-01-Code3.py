#while loop
i =1 #init
while i<10: #condition
     print(i)
     i +=1 #increment
'''
while True:
     ...
     ..
     
'''

#for
for i in range(1,10,2): # from 1 to <10, default increment is 1
     print(i)
     
     
#print in rev
for i in range(10,0,-1):
     print(i,end=',')
     
     
