i = input('enter eid ')
n = input('enter name ')

print(type(i))
print(type(n))

print('you have entered ',i)
print('you have entered ',n)

#WAP to get score in subjects in show total and avg
hs = int(input('enter mark in h '))
ms = int( input('enter mark in m '))
cs = int( input('enter mark in c '))

total = hs+ms+cs
print('total score is ',total)
avg = total/3
print('average score is ',avg)

#print grade
if avg>=80:
     print('Grade A')
elif avg>=60:
     print('Grade B')
elif avg>=40:
     print('Grade C')
else:
     print('Grade D')

     
#WAP to input 3 values from console and show largest value
     


     
     


